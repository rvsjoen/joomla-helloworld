<?php

defined('_JEXEC') or die('=;)');

jimport('joomla.application.component.view');

class HelloWorldViewHelloWorld extends JView
{
    public function display($tpl = null){
        parent::display($tpl);
    }
}
