<?php defined('_JEXEC') or die(); 

jimport('joomla.event.plugin');

class plgSystemHelloWorld extends JPlugin {
	
	function onAfterInitialise(){
		// TODO Action here
	}
	
	function onAfterRoute(){
		// TODO Action here
	}
}

?>
